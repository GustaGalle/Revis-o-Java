package Ex_17;

import java.util.TreeSet;

public class Ex_17 {
    public static void main(String[] args) {
        TreeSet<Produto> produtos = new TreeSet<>();

        produtos.add(new Produto("Notebook", 3500.00));
        produtos.add(new Produto("Smartphone", 2200.50));
        produtos.add(new Produto("Tablet", 1500.75));
        produtos.add(new Produto("Monitor", 900.00));
        produtos.add(new Produto("Mouse", 150.00));

        System.out.println("Produtos ordenados por preço:");
        for (Produto p : produtos) {
            System.out.println(p);
        }
    }
}
