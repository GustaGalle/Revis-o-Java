class ProdutoRendaFixa extends ProdutoInvestimento {
    private int carenciaMeses;

    public ProdutoRendaFixa(String nome, String descricao, double rendimentoMensal, int carenciaMeses) {
        super(nome, descricao, rendimentoMensal);
        this.carenciaMeses = carenciaMeses;
    }

    public int getCarenciaMeses() { return carenciaMeses; }

    @Override
     public double calcularRendimento(double valor, int meses) {
        if(meses < carenciaMeses) {
            System.out.println("Renda Fixa \"" + nome + "\" não considerada (carência de " + carenciaMeses + " meses).");
            return 0;
        }
        return valor * rendimentoMensal * meses;
    }
}
