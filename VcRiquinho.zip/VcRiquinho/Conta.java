import java.io.Serializable;

public abstract class Conta implements Serializable{
     private static final long serialVersionUID = 1L;
    protected String numero;
    protected double saldo;
    protected Cliente titular;

    public Conta(String numero, Cliente titular) {
        this.numero = numero;
        this.titular = titular;
        this.saldo = 0.0;
    }

    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
        }
    }

    public void sacar(double valor) {
        if (valor > 0 && saldo >= valor) {
            saldo -= valor;
        }
    }

    public double getSaldo() {
        return saldo;
    }

    public String getNumero() {
        return numero;
    }

    public Cliente getTitular() {
        return titular;
    }

    // Cada conta terá sua própria forma de calcular rendimento
    public abstract void aplicarRendimento(double cdi);
}
