import java.util.ArrayList;
import java.util.List;

public class ContaInvestimentoAutomatico extends Conta {
    private List<ProdutoInvestimento> produtosDisponiveis;

    public ContaInvestimentoAutomatico(String numero, Cliente cliente) {
        super(numero, cliente);
        this.produtosDisponiveis = new ArrayList<>();
    }

    public void adicionarProduto(ProdutoInvestimento produto) {
        produtosDisponiveis.add(produto);
    }

    public List<ProdutoInvestimento> getProdutosDisponiveis() {
        return produtosDisponiveis;
    }

    // Simulação de rendimento com taxa de serviço
    public double simularRendimento(int meses) {
        double saldoAtual = getSaldo();
        double rendimentoTotal = 0;

        for (ProdutoInvestimento produto : produtosDisponiveis) {
            rendimentoTotal += produto.calcularRendimento(saldoAtual, meses);
        }

        // Aplica a taxa de serviço
        double taxaServico = 0;
        if (getTitular() instanceof ClientePessoaFisica) {
            taxaServico = 0.001; // 0,1%
        } else if (getTitular() instanceof ClientePessoaJuridica) {
            taxaServico = 0.0015; // 0,15%
        }

        rendimentoTotal -= rendimentoTotal * taxaServico;
        return rendimentoTotal;
    }

    @Override
    public void aplicarRendimento(double cdi) {
        throw new UnsupportedOperationException("Not supported yet.");
    }
}
