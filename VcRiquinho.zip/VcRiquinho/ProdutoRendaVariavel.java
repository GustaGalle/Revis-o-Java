class ProdutoRendaVariavel extends ProdutoInvestimento {

    public ProdutoRendaVariavel(String nome, String descricao, double rendimentoMensal) {
        super(nome, descricao, rendimentoMensal);
    }

    @Override
    public double calcularRendimento(double valor, int meses) {
        return valor * rendimentoMensal * meses;
    }
}
