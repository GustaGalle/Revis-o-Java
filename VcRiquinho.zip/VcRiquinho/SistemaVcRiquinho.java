import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;




public class SistemaVcRiquinho {

    private static List<Cliente> clientes = new ArrayList<>();
    private static List<ProdutoInvestimento> produtos = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);
    private static void salvarDados() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("dados.dat"))) {
            oos.writeObject(clientes);
            oos.writeObject(produtos);
            System.out.println("Dados salvos com sucesso!");
        } catch (IOException e) {
            System.out.println("Erro ao salvar dados: " + e.getMessage());
        }
    }

    @SuppressWarnings("unchecked")
    private static void carregarDados() {
        File arquivo = new File("dados.dat");
        if (!arquivo.exists()) return;

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(arquivo))) {
            clientes = (List<Cliente>) ois.readObject();
            produtos = (List<ProdutoInvestimento>) ois.readObject();
            System.out.println("Dados carregados com sucesso!");
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Erro ao carregar dados: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        carregarDados();
        int opcao;
        do {
            System.out.println("\n===== Sistema VcRiquinho =====");
            System.out.println("1 - Gerenciar Clientes");
            System.out.println("2 - Gerenciar Produtos");
            System.out.println("3 - Simulação de Rendimento");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");
            opcao = sc.nextInt(); sc.nextLine();

            switch(opcao){
                case 1 -> menuClientes();
                case 2 -> menuProdutos();
                case 3 -> simularRendimento();
                case 0 -> salvarDados();
                default -> System.out.println("Opção inválida!");
            }
        } while(opcao != 0);
    }

    // -------------------- MENU CLIENTES --------------------
    private static void menuClientes() {
        int opcao;
        do {
            System.out.println("\n--- Gerenciar Clientes ---");
            System.out.println("1 - Adicionar Cliente");
            System.out.println("2 - Listar Clientes");
            System.out.println("3 - Atualizar Cliente");
            System.out.println("4 - Remover Cliente");
            System.out.println("5 - Ver Detalhes");
            System.out.println("6 - Depositar");
            System.out.println("7 - Sacar");
            System.out.println("8 - Adicionar Conta a Cliente");
            System.out.println("9 - Comprar Produto para Conta de Investimento");
            System.out.println("0 - Voltar");
            System.out.print("Escolha: "); 
            opcao = sc.nextInt(); sc.nextLine();

            switch(opcao){
                case 1 -> adicionarCliente();
                case 2 -> listarClientes();
                case 3 -> atualizarCliente();
                case 4 -> removerCliente();
                case 5 -> detalhesCliente();
                case 6 -> depositarConta();
                case 7 -> sacarConta();
                case 8 -> adicionarContaCliente();
                case 9 -> comprarProduto();
                case 0 -> System.out.println("Voltando...");
                default -> System.out.println("Opção inválida!");
            }
        } while(opcao != 0);
    }

    // -------------------- CLIENTE --------------------
    private static void adicionarCliente() {
        System.out.print("Tipo de cliente (PF/PJ): "); 
        String tipo = sc.nextLine().toUpperCase();
        System.out.print("Nome: "); 
        String nome = sc.nextLine();
        System.out.print("Email: "); 
        String email = sc.nextLine();

        Cliente c = null;
        if(tipo.equals("PF")) { 
            System.out.print("CPF: "); 
            String cpf = sc.nextLine(); 
            c = new ClientePessoaFisica(nome,email,cpf);
        } else if(tipo.equals("PJ")) { 
            System.out.print("CNPJ: "); 
            String cnpj = sc.nextLine(); 
            c = new ClientePessoaJuridica(nome,email,cnpj);
        } else { 
            System.out.println("Tipo inválido!"); 
            return; 
        }

        System.out.print("Tipo de conta inicial (Corrente/CDI/InvestimentoAutomatico): ");
        String tipoConta = sc.nextLine();
        Conta conta = switch(tipoConta.toUpperCase()){
            case "CORRENTE" -> new ContaCorrente("001",c);
            case "CDI" -> new ContaCDI("002",c);
            case "INVESTIMENTOAUTOMATICO" -> new ContaInvestimentoAutomatico("003",c);
            default -> { System.out.println("Conta inválida"); yield null;}
        };
        if(conta != null) c.adicionarConta(conta);

        clientes.add(c);
        System.out.println("Cliente adicionado!");
    }

    private static void listarClientes() {
        if(clientes.isEmpty()){ 
            System.out.println("Nenhum cliente"); 
            return;
        }
        System.out.println("--- Lista de Clientes ---");
        for(int i=0;i<clientes.size();i++){ 
            Cliente c = clientes.get(i);
            System.out.println(i + " - " + c.getNome() + " ("+c.getClass().getSimpleName()+")");
        }
    }

    private static void atualizarCliente() {
        listarClientes();
        System.out.print("Escolha índice: "); int idx = sc.nextInt(); sc.nextLine();
        if(idx<0 || idx>=clientes.size()){ 
            System.out.println("Índice inválido!"); 
            return;
        }
        Cliente c = clientes.get(idx);
        System.out.print("Novo nome ("+c.getNome()+"): "); String nome = sc.nextLine();
        System.out.print("Novo email ("+c.getEmail()+"): "); String email = sc.nextLine();
        if(!nome.isEmpty()) c.setNome(nome);
        if(!email.isEmpty()) c.setEmail(email);
        System.out.println("Cliente atualizado!");
    }

    private static void removerCliente() {
        listarClientes();
        System.out.print("Escolha índice: "); int idx = sc.nextInt(); sc.nextLine();
        if(idx<0 || idx>=clientes.size()){ 
            System.out.println("Índice inválido!"); 
            return;
        }
        Cliente c = clientes.remove(idx);
        System.out.println("Cliente removido: " + c.getNome());
    }

    private static void detalhesCliente() {
        if(clientes.isEmpty()){ 
            System.out.println("Nenhum cliente"); 
            return;
        }
        System.out.println("--- Detalhes dos Clientes ---");
        for(Cliente c : clientes){
            System.out.println("Nome: "+c.getNome()+", Email: "+c.getEmail());
            if(c instanceof ClientePessoaFisica pf) System.out.println("CPF: "+pf.getCpf());
            if(c instanceof ClientePessoaJuridica pj) System.out.println("CNPJ: "+pj.getCnpj());
            System.out.println("Contas:");
            for(Conta ct : c.getContas()){
                System.out.println(" - "+ct.getNumero()+" ("+ct.getClass().getSimpleName()+") | Saldo: "+ct.getSaldo());
                if(ct instanceof ContaInvestimentoAutomatico cia){
                    System.out.println("   Produtos:");
                    for(ProdutoInvestimento p : cia.getProdutosDisponiveis())
                        System.out.println("    - "+p.getNome()+" | "+(p.getRendimentoMensal()*100)+"%");
                }
            }
            System.out.println("-----------------------");
        }
    }

    private static void depositarConta() {
        listarClientes();
        System.out.print("Escolha índice do cliente: "); int idx = sc.nextInt(); sc.nextLine();
        Cliente c = clientes.get(idx);
        if(c.getContas().isEmpty()){ 
            System.out.println("Cliente não possui contas"); 
            return;
        }
        System.out.println("Escolha índice da conta:");
        for(int i=0;i<c.getContas().size();i++){ 
            Conta ct = c.getContas().get(i);
            System.out.println(i + " - " + ct.getNumero() + " (" + ct.getClass().getSimpleName() + ")");
        }
        int cIdx = sc.nextInt(); sc.nextLine();
        Conta ct = c.getContas().get(cIdx);
        System.out.print("Valor a depositar: "); double val = sc.nextDouble(); sc.nextLine();
        ct.depositar(val);
        System.out.println("Depósito realizado!");
    }

    private static void sacarConta() {
        listarClientes();
        System.out.print("Escolha índice do cliente: "); int idx = sc.nextInt(); sc.nextLine();
        Cliente c = clientes.get(idx);
        if(c.getContas().isEmpty()){ 
            System.out.println("Cliente não possui contas"); 
            return;
        }
        System.out.println("Escolha índice da conta:");
        for(int i=0;i<c.getContas().size();i++){ 
            Conta ct = c.getContas().get(i);
            System.out.println(i + " - " + ct.getNumero() + " (" + ct.getClass().getSimpleName() + ")");
        }
        int cIdx = sc.nextInt(); sc.nextLine();
        Conta ct = c.getContas().get(cIdx);
        System.out.print("Valor a sacar: "); double val = sc.nextDouble(); sc.nextLine();
        ct.sacar(val);
        System.out.println("Saque realizado!");
    }

    private static void adicionarContaCliente() {
        listarClientes();
        System.out.print("Escolha índice do cliente: "); int idx = sc.nextInt(); sc.nextLine();
        if(idx < 0 || idx >= clientes.size()){ 
            System.out.println("Índice inválido"); 
            return; 
        }
        Cliente c = clientes.get(idx);

        System.out.print("Tipo de conta a adicionar (Corrente/CDI/InvestimentoAutomatico): ");
        String tipoConta = sc.nextLine();
        int numeroConta = c.getContas().size() + 1; // gera número sequencial simples
        Conta conta = switch(tipoConta.toUpperCase()){
            case "CORRENTE" -> new ContaCorrente(String.format("%03d", numeroConta), c);
            case "CDI" -> new ContaCDI(String.format("%03d", numeroConta), c);
            case "INVESTIMENTOAUTOMATICO" -> new ContaInvestimentoAutomatico(String.format("%03d", numeroConta), c);
            default -> { System.out.println("Tipo de conta inválido"); yield null; }
        };
        if(conta != null){
            c.adicionarConta(conta);
            System.out.println("Conta adicionada ao cliente!");
        }
    }

    // -------------------- MENU PRODUTOS --------------------
    private static void menuProdutos() {
        int opcao;
        do{
            System.out.println("\n--- Gerenciar Produtos ---");
            System.out.println("1 - Adicionar Produto");
            System.out.println("2 - Listar Produtos");
            System.out.println("3 - Atualizar Produto");
            System.out.println("4 - Remover Produto");
            System.out.println("0 - Voltar");
            System.out.print("Escolha: "); 
            opcao=sc.nextInt(); sc.nextLine();

            switch(opcao){
                case 1 -> adicionarProduto();
                case 2 -> listarProdutos();
                case 3 -> atualizarProduto();
                case 4 -> removerProduto();
                case 0 -> System.out.println("Voltando...");
                default -> System.out.println("Opção inválida!");
            }
        }while(opcao!=0);
    }

    private static void adicionarProduto() {
        System.out.print("Tipo de produto (RendaFixa/RendaVariavel): "); 
        String tipo = sc.nextLine();
        System.out.print("Nome: "); String nome = sc.nextLine();
        System.out.print("Rendimento mensal (%): "); double rend = sc.nextDouble()/100.0; sc.nextLine();

        if(tipo.equalsIgnoreCase("RendaFixa")){
            System.out.print("Meses de carência: "); int carencia = sc.nextInt(); sc.nextLine();
            produtos.add(new ProdutoRendaFixa(nome,"",rend,carencia));
        }
        else if(tipo.equalsIgnoreCase("RendaVariavel")) 
            produtos.add(new ProdutoRendaVariavel(nome,"",rend));
        else{
            System.out.println("Tipo inválido!"); 
            return;
        }
        System.out.println("Produto adicionado!");
    }

    private static void listarProdutos() {
        if(produtos.isEmpty()){ 
            System.out.println("Nenhum produto"); 
            return;
        }
        System.out.println("--- Lista de Produtos ---");
        for(int i=0;i<produtos.size();i++){ 
            ProdutoInvestimento p = produtos.get(i);
            System.out.println(i + " - " + p.getNome() + " (" + p.getClass().getSimpleName() + ")");
        }
    }

    private static void atualizarProduto() {
        listarProdutos();
        System.out.print("Escolha índice: "); int idx = sc.nextInt(); sc.nextLine();
        if(idx<0 || idx>=produtos.size()){ 
            System.out.println("Índice inválido"); 
            return;
        }
        ProdutoInvestimento p = produtos.get(idx);
        System.out.print("Novo nome ("+p.getNome()+"): "); String nome = sc.nextLine();
        if(!nome.isEmpty()) p.nome = nome;
        System.out.println("Atualizado!");
    }

    private static void removerProduto() {
        listarProdutos();
        System.out.print("Escolha índice: "); int idx = sc.nextInt(); sc.nextLine();
        if(idx<0 || idx>=produtos.size()){ 
            System.out.println("Índice inválido"); 
            return;
        }
        ProdutoInvestimento p = produtos.remove(idx);
        System.out.println("Produto removido: " + p.getNome());
    }

    // -------------------- COMPRAR PRODUTO --------------------
    private static void comprarProduto() {
        listarClientes();
        System.out.print("Escolha índice do cliente: ");
        int idx = sc.nextInt(); sc.nextLine();
        if(idx < 0 || idx >= clientes.size()){ 
            System.out.println("Índice inválido"); 
            return; 
        }
        Cliente c = clientes.get(idx);

        List<ContaInvestimentoAutomatico> contasInv = new ArrayList<>();
        for(Conta ct : c.getContas()){
            if(ct instanceof ContaInvestimentoAutomatico cia) contasInv.add(cia);
        }
        if(contasInv.isEmpty()){ 
            System.out.println("Cliente não possui contas de investimento automático."); 
            return; 
        }

        System.out.println("Escolha a conta de investimento automático:");
        for(int i=0;i<contasInv.size();i++){
            ContaInvestimentoAutomatico cia = contasInv.get(i);
            System.out.println(i + " - " + cia.getNumero() + " | Saldo: " + cia.getSaldo());
        }
        int cIdx = sc.nextInt(); sc.nextLine();
        ContaInvestimentoAutomatico contaEscolhida = contasInv.get(cIdx);

        listarProdutos();
        System.out.print("Escolha índice do produto para adicionar: ");
        int pIdx = sc.nextInt(); sc.nextLine();
        if(pIdx < 0 || pIdx >= produtos.size()){ 
            System.out.println("Produto inválido!"); 
            return; 
        }
        ProdutoInvestimento produto = produtos.get(pIdx);

        contaEscolhida.adicionarProduto(produto);
        System.out.println("Produto \"" + produto.getNome() + "\" adicionado à conta de investimento automático!");
    }

    // -------------------- SIMULAÇÃO --------------------
    private static void simularRendimento() {
        listarClientes();
        System.out.print("Escolha índice do cliente: "); int idx = sc.nextInt(); sc.nextLine();
        Cliente c = clientes.get(idx);
        System.out.println("Escolha conta para simulação:");
        for(int i=0;i<c.getContas().size();i++){ 
            Conta ct = c.getContas().get(i);
            System.out.println(i + " - " + ct.getNumero() + " (" + ct.getClass().getSimpleName() + ")");
        }
        int cIdx = sc.nextInt(); sc.nextLine();
        Conta ct = c.getContas().get(cIdx);

        System.out.print("Meses para simulação: "); int meses = sc.nextInt(); sc.nextLine();
        if(ct instanceof ContaInvestimentoAutomatico cia){
            double rendimento = cia.simularRendimento(meses);
            System.out.println("Rendimento líquido após "+meses+" meses: "+rendimento);
        }else{
            System.out.println("Conta não é de investimento automático.");
        }
    }

    
}
