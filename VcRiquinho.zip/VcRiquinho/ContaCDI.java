public class ContaCDI extends Conta {
    public ContaCDI(String numero, Cliente titular) {
        super(numero, titular);
    }

    @Override
    public void aplicarRendimento(double cdi) {
        double rendimentoBruto = saldo * (cdi / 30.0);
        double taxa = rendimentoBruto * 0.0007; 
        saldo += (rendimentoBruto - taxa);
    }
}
