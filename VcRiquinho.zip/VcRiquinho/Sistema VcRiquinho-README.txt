Sistema VcRiquinho - README

Aluno: Gustavo Tadeu Gallego da Silva
GU: 3046435
-------------------------------------------
Decisões de Design:
-------------------

1. Estrutura de Classes:
   - Cliente: abstrato, representando tanto pessoas físicas quanto jurídicas. 
   - ClientePessoaFisica e ClientePessoaJuridica: herdam de Cliente, adicionando campos específicos (CPF ou CNPJ).
   - Conta: abstrata, com operações comuns de depósito, saque e aplicação de rendimento.
   - ContaCorrente, ContaCDI e ContaInvestimentoAutomatico: herdam de Conta. Cada tipo implementa comportamentos específicos de rendimento.
   - ProdutoInvestimento: abstrato, com métodos para cálculo de rendimento. Permite criar produtos variados sem alterar as contas.
   - ProdutoRendaFixa e ProdutoRendaVariavel: herdam de ProdutoInvestimento, com regras específicas de cálculo e carência.

2. Relações:
   - Cliente possui múltiplas contas (composição);
   - ContaInvestimentoAutomatico contém múltiplos produtos (composição);
   - Herança utilizada para especializar clientes, contas e produtos.

3. Persistência de Dados:
   - Os dados de clientes e produtos são salvos em arquivo binário local (`dados.dat`) usando `ObjectOutputStream`.
   - Ao iniciar o sistema, os dados são carregados com `ObjectInputStream`.

4. Interface do Usuário:
   - Sistema de menu textual via console.
   - Menus separados para clientes, contas e produtos.
   - Opção de simulação de rendimento para contas de investimento automático, reforçando o propósito do sistema.

5. Justificativa do Design:
   - Uso de herança e polimorfismo facilita manutenção e futura expansão (ex.: novos tipos de contas ou produtos).
   - Separação clara de responsabilidades: Cliente gerencia contas, Conta gerencia saldo e rendimento, ProdutoInvestimento calcula rendimentos.
   - Persistência local simplificada garante que o protótipo possa ser testado sem dependências externas.

