public class ContaCorrente extends Conta {
    public ContaCorrente(String numero, Cliente titular) {
        super(numero, titular);
    }

    @Override
    public void aplicarRendimento(double cdi) {
        
    }
}
