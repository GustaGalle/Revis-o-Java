import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public abstract class Cliente implements Serializable {
     private static final long serialVersionUID = 1L;
    private int id;
    private String nome;
    private String email;
    protected List<Conta> contas;

    // Construtor
    public Cliente(String nome, String email) {
        this.nome = nome;
        this.email = email;
        this.contas = new ArrayList<>();
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    // Adiciona uma conta ao cliente
    public void adicionarConta(Conta conta) {
        contas.add(conta);
    }

    // Remove uma conta
    public void removerConta(Conta conta) {
        contas.remove(conta);
    }

    // Retorna a lista de contas do cliente
public List<Conta> getContas() {
    return contas;
}



    // Método para exibir informações do cliente
    @Override
    public String toString() {
        return "Cliente { " +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", email='" + email + '\'' +
                " }";
    }
}
