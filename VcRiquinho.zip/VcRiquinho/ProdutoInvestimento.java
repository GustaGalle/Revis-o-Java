import java.io.Serializable;

public abstract class ProdutoInvestimento implements Serializable {
     private static final long serialVersionUID = 1L;
    protected String nome;
    protected String descricao;
    protected double rendimentoMensal; // em percentual (ex: 0.01 = 1%)

    public ProdutoInvestimento(String nome, String descricao, double rendimentoMensal) {
        this.nome = nome;
        this.descricao = descricao;
        this.rendimentoMensal = rendimentoMensal;
    }

    public String getNome() { return nome; }
    public String getDescricao() { return descricao; }
    public double getRendimentoMensal() { return rendimentoMensal; }
    
    // Método abstrato para cálculo do rendimento em X meses
    public abstract double calcularRendimento(double valor, int meses);
}
