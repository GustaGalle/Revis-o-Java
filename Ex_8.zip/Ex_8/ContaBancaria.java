package Ex_8;

public class ContaBancaria {
    private String titular;
    private Double saldo;

    public ContaBancaria(String titular, double saldo) {
        this.titular = titular;
        this.saldo = saldo;
    }
    
    public double getSaldo() {return saldo;}

    public void depositar(double valor) {
        if (valor > 0) {
            saldo += valor;
        } else {
            System.out.println("Valor inválido para depósito.");
        }
    }

   public void sacar(double valor) throws SaldoInsuficienteException {
        if (valor <= 0) {
            throw new IllegalArgumentException("Valor de saque inválido.");
        }
        if (valor > saldo) {
            throw new SaldoInsuficienteException(
                "Saldo insuficiente. Saldo atual: R$ " + saldo + ", tentativa de saque: R$ " + valor
            );
        }
        saldo -= valor;
    }

    

}