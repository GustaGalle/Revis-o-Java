package Ex_8;

public class TesteConta {
    public static void main(String[] args) {
        ContaBancaria conta = new ContaBancaria("Ana", 500.0);

        conta.depositar(200.0);
        System.out.println("Saldo atual: R$ " + conta.getSaldo());

        try {
            System.out.println("Tentando sacar R$ 800...");
            conta.sacar(800.0); // vai lançar a exceção
        } catch (SaldoInsuficienteException e) {
            System.out.println("Erro: " + e.getMessage());
        }

        System.out.println("Saldo final: R$ " + conta.getSaldo());
    }
}

