package Ex_26;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class Ex_26 {
    public static void main(String[] args) {
        Map<String, List<Produto>> catalogo = new HashMap<>();

        // Criando listas de produtos por categoria
        List<Produto> eletronicos = new ArrayList<>();
        eletronicos.add(new Produto("Smartphone", 2200.50));
        eletronicos.add(new Produto("Notebook", 3500.00));
        eletronicos.add(new Produto("Tablet", 1500.75));

        List<Produto> roupas = new ArrayList<>();
        roupas.add(new Produto("Camiseta", 59.90));
        roupas.add(new Produto("Calça Jeans", 120.00));
        roupas.add(new Produto("Tênis", 250.00));

        // Adicionando categorias no mapa
        catalogo.put("Eletrônicos", eletronicos);
        catalogo.put("Roupas", roupas);

        Scanner sc = new Scanner(System.in);
        System.out.print("Digite a categoria que deseja listar (Eletrônicos/Roupas): ");
        String categoria = sc.nextLine().trim();

        List<Produto> produtosCategoria = catalogo.get(categoria);

        if (produtosCategoria != null) {
            System.out.println("Produtos da categoria \"" + categoria + "\":");
            for (Produto p : produtosCategoria) {
                System.out.println(p);
            }
        } else {
            System.out.println("Categoria \"" + categoria + "\" não encontrada.");
        }

        sc.close();
    }
}

