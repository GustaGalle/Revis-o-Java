package Ex_30;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Ex_30 {
    public static void main(String[] args) {
        List<Aluno> alunos = new ArrayList<>();
        alunos.add(new Aluno("Ana", 8.5));
        alunos.add(new Aluno("Bruno", 6.0));
        alunos.add(new Aluno("Carla", 4.5));
        alunos.add(new Aluno("Diego", 7.0));
        alunos.add(new Aluno("Eduardo", 5.5));
        alunos.add(new Aluno("Fernanda", 3.0));

        Map<String, List<Aluno>> agrupamento = new HashMap<>();

        agrupamento.put("Aprovados", new ArrayList<>());
        agrupamento.put("Recuperação", new ArrayList<>());
        agrupamento.put("Reprovados", new ArrayList<>());

        for (Aluno aluno : alunos) {
            if (aluno.getNota() >= 7) {
                agrupamento.get("Aprovados").add(aluno);
            } else if (aluno.getNota() >= 5) {
                agrupamento.get("Recuperação").add(aluno);
            } else {
                agrupamento.get("Reprovados").add(aluno);
            }
        }

        // agrupamento
        for (Map.Entry<String, List<Aluno>> entry : agrupamento.entrySet()) {
            System.out.println(entry.getKey() + ":");
            for (Aluno aluno : entry.getValue()) {
                System.out.println("  - " + aluno);
            }
        }
    }
}
